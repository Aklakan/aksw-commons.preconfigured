Sebastian Hellmann
This is a preconfigured Joseki.
It will load the Data in the file Data/data.ttl
replace it and then start it and go to http://localhost:2020

The script start-joseki.sh specifies that the data is reloaded every 15minutes
also the script reload-data.sh is called everytime

Please go to the home page of Joseki for anything else.

Joseki: The Jena RDF Server
===========================

    http://www.joseki.org/

	Andy Seaborne
	andy.seaborne@epimorphics.com

Joseki is a server implementing the SPARQL protocol.

