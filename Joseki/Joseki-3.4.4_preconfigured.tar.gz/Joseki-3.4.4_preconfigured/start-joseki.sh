#!/bin/sh

CONFIG=joseki-config.ttl 
INTERVAL=15m
./reload-data.sh

# Loop forever (A cronjob is more suitable, this is for developing)
while :
do
java -cp :./lib/tdb-0.8.10.jar:./lib/iri-0.8.jar:./lib/stax-api-1.0.1.jar:./lib/arq-2.8.8-tests.jar:./lib/jetty-util-6.1.25.jar:./lib/lucene-core-2.3.1.jar:./lib/junit-4.5.jar:./lib/jetty-6.1.25.jar:./lib/jena-2.6.4-tests.jar:./lib/wstx-asl-3.2.9.jar:./lib/arq-2.8.8.jar:./lib/log4j-1.2.14.jar:./lib/slf4j-api-1.5.8.jar:./lib/jena-2.6.4.jar:./lib/icu4j-3.4.4.jar:./lib/joseki-3.4.4.jar:./lib/xercesImpl-2.7.1.jar:./lib/servlet-api-2.5-20081211.jar:./lib/slf4j-log4j12-1.5.8.jar:./lib/sdb-1.3.4.jar:./joseki-3.4.4-sources.jar joseki.rdfserver $CONFIG &
PID=`ps -ef | grep '[j]oseki.rdfserver joseki-config.ttl' | awk '{print $2}'`
echo "Running joseki with process Id: "$PID
echo $INTERVAL" minutes till reload"
sleep $INTERVAL
echo "reloading.."
kill $PID
# wait 5 seconds for the process to get killed 
# the dump script can be executed here
# if the dumps script need more than 5 seconds the waiting is unnecessary
sleep 5s
./reload-data.sh
done # Start over
