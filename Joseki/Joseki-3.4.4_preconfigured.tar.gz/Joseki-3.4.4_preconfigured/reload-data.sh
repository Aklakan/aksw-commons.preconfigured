#!/bin/sh
# This is just an example:
# URL='http://klappstuhlclub.de/wp/wp-content/plugins/RDF2WP/Output/EntireBlogExporter.php?format=text/plain'
# curl $URL  > Data/data.ttl
