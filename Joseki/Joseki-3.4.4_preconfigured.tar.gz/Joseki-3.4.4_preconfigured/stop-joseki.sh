#!/bin/sh
PID=`ps -ef | grep '[j]oseki.rdfserver joseki-config.ttl' | awk '{print $2}'`

echo "trying to stop joseki with process id ["$PID"]"
kill  $PID

